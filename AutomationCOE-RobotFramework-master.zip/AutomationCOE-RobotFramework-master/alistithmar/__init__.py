from library import Browser

from alistithmar.pages import AlistithmarPages


class Alistithmar:

    def __init__(self, browser):
        self.browser: Browser = browser
        self.pages = AlistithmarPages(browser=self.browser)
        pass
