import os
import sys

from library import Browser
from alistithmar import Alistithmar

from robot.api.deco import keyword
from robot.libraries.BuiltIn import BuiltIn


class AlistithmarCapital:

    def __init__(self):
        self.root_dir = os.path.dirname(sys.modules['__main__'].__file__)
        self.browser: Browser = Browser()
        self.application = Alistithmar(browser=self.browser)
        pass

    # Application specific keywords
    @keyword
    def open_the_application(self, url: str):
        self.browser.launch_chrome_browser(url=url)
        pass

    @keyword
    def login_to_trading_platform(self, username: str, password: str):
        self.application.pages.login_page.login(username=username, password=password)
        self.assert_login_page_displayed()
        pass

    @keyword
    def logout_of_trading_platform(self):
        self.application.pages.home.title_bar.logout()
        pass

    @keyword
    def close_the_application(self):
        self.browser.close_browser()
        pass

    @keyword
    def place_buy_order(self, order: dict):
        self.application.pages.home.widget.saudi_stock_exchange.place_buy_order(order=order)
        pass

    @keyword
    def save_to_basket(self, order: dict):
        self.application.pages.home.widget.new_order.save_to_basket(order=order)
        pass

    @keyword
    def delete_workspace_if_exist(self, workspace_name: str):
        if self.application.pages.home.menu.is_workspace_exist(workspace_name=workspace_name):
            self.application.pages.home.menu.delete_workspace(workspace_name=workspace_name)
        pass

    @keyword
    def create_workspace(self, layout: int = 1):
        self.application.pages.home.menu.create_workspace(layout=layout)
        pass

    @keyword
    def save_to_basket(self, order: dict):
        self.application.pages.home.widget.new_order.save_to_basket(order=order)
        pass

    # Assert functions
    @keyword
    def assert_login_page_displayed(self):
        self.application.pages.login_page.assert_login_page_displayed()
        pass

    @keyword
    def assert_login_page_session_expired_message(self):
        self.application.pages.login_page.assert_session_expired()
        pass

    @keyword
    def assert_account_holder_name(self, account_holder_name: str):
        self.application.pages.home.title_bar.assert_account_holder_name(account_holder_name=account_holder_name)
        pass

    @keyword
    def assert_active_menu(self, menu: str, sub_menu: str):
        self.application.pages.home.menu.assert_active_menu(menu=menu, sub_menu=sub_menu)
        pass

    @keyword
    def assert_order_rejected(self, message: str):
        self.application.pages.home.title_bar.assert_order_rejected(message=message)
        pass

    @keyword
    def assert_order_list_entry(self, order: dict):
        self.application.pages.home.widget.order_list.assert_order_list_entry(order=order)
        pass

    @keyword
    def assert_saved_orders_entry(self, order: dict):
        self.application.pages.home.widget.saved_orders.assert_saved_orders_list_entry(order=order)
        pass

    @keyword
    def assert_workspace_created(self, workspace_name: str):
        self.application.pages.home.menu.assert_workspace_created(workspace_name=workspace_name)
        pass

    def on_failure_take_screenshot(self):
        root = os.path.dirname(sys.modules['__main__'].__file__)
        screenshot = os.path.join(root, 'results', 'screenshot')
        if not os.path.exists(screenshot):
            os.makedirs(screenshot)
        test_status = BuiltIn().get_variable_value("${TEST STATUS}")
        test_name = BuiltIn().get_variable_value("${TEST NAME}")

        if test_status != "PASS":
            screen_shot = os.path.join(screenshot, test_name + '.png')
            self.browser.take_screenshot(screen_shot)
        pass
