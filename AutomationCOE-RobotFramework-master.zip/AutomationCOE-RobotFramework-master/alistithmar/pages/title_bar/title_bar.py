from robot.libraries.BuiltIn import BuiltIn

from selenium.webdriver.common.by import By

from library import Browser


class TitleBar:
    # Objects
    # Button
    _BTN_Logout = (By.XPATH, '//a[@data-hint="Log Out"]', 'Logout button.')

    # Elements / Dynamic values
    _ELM_Account_holder_name = (
        By.XPATH, '//div[@id="appTitle"]/div[contains(@class,"username")]', 'Account holder name element.')

    _ELM_Title_banner_message = (
        By.XPATH, '//div[@data-id="title-middle"]//span[contains(@class,"single-message-content")]',
        'Title banner message element.')

    def __init__(self, browser: Browser):
        self.browser = browser
        pass

    # Page functions
    def logout(self):
        self.browser.wait_for_element_visible(locator=TitleBar._BTN_Logout)
        self.browser.click(locator=TitleBar._BTN_Logout)
        pass

    def is_banner_displayed(self, message, timeout: int = 1):
        for i in range(1, 60 * timeout):
            value = self.browser.find_element(locator=TitleBar._ELM_Title_banner_message).get_attribute(
                name='innerText')
            if message in value:
                return True
            pass
        return False
        pass

    # Verify functions

    # Assert functions
    def assert_account_holder_name(self, account_holder_name: str):
        self.browser.wait_for_element_visible(locator=TitleBar._ELM_Account_holder_name)
        BuiltIn().run_keyword('should be equal', self.browser.get_text(locator=TitleBar._ELM_Account_holder_name),
                              account_holder_name, 'Account holder name.')
        pass

    def assert_order_rejected(self, message: str):
        self.browser.wait_for_element_visible(locator=TitleBar._ELM_Title_banner_message)

        BuiltIn().run_keyword('should be true', self.is_banner_displayed(message=message),
                              message + ' displayed holder name.')
        pass
