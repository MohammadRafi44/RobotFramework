from alistithmar.pages.widget.widget import Widget
