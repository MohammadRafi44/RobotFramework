import time

from selenium.webdriver.common.by import By

from library import Browser


class SaudiStockExchangeWidget:
    # Objects
    # Button
    _BTN_Context_Menu_Buy = (
        By.XPATH, '//div[@container-id="popupId"]//div[contains(@class,"right-click-menu-item")]//div[text()="Buy"]',
        'Context menu Buy button')

    _BTN_New_order_PopUp_Buy = (By.XPATH, '//div[contains(@class,"popup-widget")]//button[contains(text(),"Buy")]',
                                'New order popup Buy button')

    _BTN_New_order_PopUp_Confirm_Order = \
        (By.XPATH, '//div[contains(@class,"popup-widget")]//button[@data-id="orderConfirmationBtn"]',
         'New order popup Confirm_Order button')

    # Elements
    # PopUp
    _ELM_Context_Menu_PopUp = (By.XPATH,
                               '//div[@container-id="popupId"]/div[@class="right-click-menu"]',
                               'Context menu popup element')

    _ELM_New_Order_PopUp = (By.XPATH, '//div[contains(@class,"popup-widget")]', 'New order popup element')

    # Text
    _TXT_New_order_PopUp_Search = (
        By.XPATH, '//div[contains(@class,"popup-widget")]//input[contains(@id,"searchField")]',
        'New order popup Search input field.')
    _TXT_New_order_PopUp_Quantity = (
        By.XPATH, '//div[contains(@class,"popup-widget")]//input[contains(@id,"qtyField")]',
        'New order popup Quantity input field.')
    _TXT_New_order_PopUp_Price = (
        By.XPATH, '//div[contains(@class,"popup-widget")]//input[contains(@id,"orderPriceId")]',
        'New order popup Price input field.')

    # Drop Down
    _BTN_DRP_New_order_PopUp_Order_Type = (
        By.XPATH, '//div[contains(@class,"popup-widget")]//div[text()="Order Type"]/following-sibling::div'
                  '//button[contains(@class,"btn-dropdown")]', 'New order popup Order Type button.')
    _ELM_DRP_New_order_PopUp_Order_Type_Value = (
        By.XPATH, '//div[contains(@class,"popup-widget")]//div[text()="Order Type"]/following-sibling::div'
                  '//button[contains(@class,"btn-dropdown")]/div/div', 'New order popup Order Type value element.')

    _BTN_DRP_New_order_PopUp_Good_Till = (
        By.XPATH, '//div[contains(@class,"popup-widget")]//div[text()="Good Till"]/following-sibling::div'
                  '//button[contains(@class,"btn-dropdown")]', 'New order popup Good Till button.')
    _ELM_DRP_New_order_PopUp_Good_Till_Value = (
        By.XPATH, '//div[contains(@class,"popup-widget")]//div[text()="Good Till"]/following-sibling::div'
                  '//button[contains(@class,"btn-dropdown")]/div/div', 'New order popup Good Till value element.')

    # Methods for Dynamic XPaths
    @staticmethod
    def get_elm_s_description(s_description: str):
        xpath = '//div[contains(@id,"watchListContainer")]//div[contains(@id,"table")]//div[@cell-id="dataObj.sDes"]' \
                '/span[text()="{s_description}"]'.replace('{s_description}', s_description)
        return By.XPATH, xpath, 'S.Description element.'

    @staticmethod
    def get_elm_drp_option_new_order_popup(value: str):
        xpath = '//div[@container-id="popupId"]//a[text()="{value}"]'.replace('{value}', value)
        return By.XPATH, xpath, 'New order popup drop down option element.'

    def __init__(self, browser: Browser):
        self.browser = browser
        pass

    # Page functions
    def place_buy_order(self, order: dict):
        s_description = order['s_description']
        order_type = order['order_type']
        quantity = order['quantity']
        price = order['price']
        good_till = order['good_till']

        self.browser.wait_for_element_visible(
            locator=SaudiStockExchangeWidget.get_elm_s_description(s_description=s_description))
        self.browser.right_click(locator=SaudiStockExchangeWidget.get_elm_s_description(s_description=s_description))

        self.browser.wait_for_element_visible(locator=SaudiStockExchangeWidget._BTN_Context_Menu_Buy)
        self.browser.click(locator=SaudiStockExchangeWidget._BTN_Context_Menu_Buy)

        self.browser.wait_for_element_visible(locator=SaudiStockExchangeWidget._BTN_New_order_PopUp_Buy)
        self.browser.set_text(locator=SaudiStockExchangeWidget._TXT_New_order_PopUp_Quantity, value=quantity)
        self.browser.set_text(locator=SaudiStockExchangeWidget._TXT_New_order_PopUp_Price, value=price)
        self.browser.select_drop_down(button=SaudiStockExchangeWidget._BTN_DRP_New_order_PopUp_Order_Type,
                                      value_element=SaudiStockExchangeWidget.get_elm_drp_option_new_order_popup(
                                          value=order_type), value=order_type)
        self.browser.select_drop_down(button=SaudiStockExchangeWidget._BTN_DRP_New_order_PopUp_Good_Till,
                                      value_element=SaudiStockExchangeWidget.get_elm_drp_option_new_order_popup(
                                          value=good_till), value=good_till)
        time.sleep(2)
        self.browser.click(locator=SaudiStockExchangeWidget._BTN_New_order_PopUp_Buy)

        self.browser.wait_for_element_visible(locator=SaudiStockExchangeWidget._BTN_New_order_PopUp_Confirm_Order)
        self.browser.click(locator=SaudiStockExchangeWidget._BTN_New_order_PopUp_Confirm_Order)
        pass

    # Verify functions

    # Assert functions
