from robot.libraries.BuiltIn import BuiltIn

from selenium.webdriver.common.by import By

from library import Browser


class SavedOrdersWidget:
    # Objects
    # Tab
    _TAB_Saved_orders = (By.XPATH, '//div[@data-id="orderList-full"]//div[not(contains(@class,"active")) and '
                                   'contains(@class,"wdgttl-tab-item")]/a/span[text()="Saved Orders"]',
                         'Saved orders Tab')
    _TAB_Saved_orders_Active = (By.XPATH, '//div[@data-id="orderList-full"]//div[contains(@class,"active") and '
                                          'contains(@class,"wdgttl-tab-item")]/a/span[text()="Saved Orders"]',
                                'Saved orders Tab active')

    # Methods for Dynamic XPaths
    @staticmethod
    def get_elm_saved_orders_side(s_description: str):
        xpath = '//div[@data-id="orderList-full"]//div[@cell-id="symbolInfo.sDes"]' \
                '/span[text()="{s_description}"]/ancestor::div[contains(@class,"table-row")]' \
                '//div[@cell-id="ordSide"]/span'.replace('{s_description}', s_description)
        return By.XPATH, xpath, 'Saved orders side element.'

    @staticmethod
    def get_elm_saved_orders_quantity(s_description: str):
        xpath = '//div[@data-id="orderList-full"]//div[@cell-id="symbolInfo.sDes"]' \
                '/span[text()="{s_description}"]/ancestor::div[contains(@class,"table-row")]' \
                '//div[@cell-id="ordQty"]/span'.replace('{s_description}', s_description)
        return By.XPATH, xpath, 'Saved orders Quantity element.'

    @staticmethod
    def get_elm_saved_orders_symbol(s_description: str):
        xpath = '//div[@data-id="orderList-full"]//div[@cell-id="symbolInfo.sDes"]' \
                '/span[text()="{s_description}"]/ancestor::div[contains(@class,"table-row")]' \
                '//div[@cell-id="symbol"]/span'.replace('{s_description}', s_description)
        return By.XPATH, xpath, 'Saved orders symbol element.'

    @staticmethod
    def get_elm_saved_orders_s_description(s_description: str):
        xpath = '//div[@data-id="orderList-full"]//div[@cell-id="symbolInfo.sDes"]' \
                '/span[text()="{s_description}"]'.replace('{s_description}', s_description)
        return By.XPATH, xpath, 'Saved orders S.Description element.'

    @staticmethod
    def get_elm_saved_orders_order_type(s_description: str):
        xpath = '//div[@data-id="orderList-full"]//div[@cell-id="symbolInfo.sDes"]' \
                '/span[text()="{s_description}"]/ancestor::div[contains(@class,"table-row")]' \
                '//div[@cell-id="ordTyp"]/span'.replace('{s_description}', s_description)
        return By.XPATH, xpath, 'Saved orders Order type element.'

    @staticmethod
    def get_elm_saved_orders_price(s_description: str):
        xpath = '//div[@data-id="orderList-full"]//div[@cell-id="symbolInfo.sDes"]' \
                '/span[text()="{s_description}"]/ancestor::div[contains(@class,"table-row")]' \
                '//div[@cell-id="price"]/span'.replace('{s_description}', s_description)
        return By.XPATH, xpath, 'Saved orders Price element.'

    def __init__(self, browser: Browser):
        self.browser = browser
        pass

    # Page functions
    def switch_to_saved_orders_tab(self):
        if not self.browser.is_element_present(locator=SavedOrdersWidget._TAB_Saved_orders_Active):
            self.browser.click(locator=SavedOrdersWidget._TAB_Saved_orders)
        self.browser.wait_for_element_present(locator=SavedOrdersWidget._TAB_Saved_orders_Active)
        pass

    # Verify functions

    # Assert functions
    def assert_saved_orders_list_entry(self, order: dict):
        self.switch_to_saved_orders_tab()
        side = order['side']
        quantity = order['quantity']
        symbol = order['symbol']
        s_description = order['s_description']
        order_type = order['order_type']

        BuiltIn().run_keyword('should be equal',
                              self.browser.get_text(
                                  SavedOrdersWidget.get_elm_saved_orders_side(s_description=s_description)),
                              side, 'Saved orders Side element.')

        BuiltIn().run_keyword('should be equal',
                              self.browser.get_text(
                                  SavedOrdersWidget.get_elm_saved_orders_quantity(s_description=s_description)),
                              quantity, 'Saved orders Quantity element.')

        BuiltIn().run_keyword('should be equal',
                              self.browser.get_text(
                                  SavedOrdersWidget.get_elm_saved_orders_symbol(s_description=s_description)),
                              symbol, 'Saved orders Symbol element.')

        BuiltIn().run_keyword('should be equal',
                              self.browser.get_text(
                                  SavedOrdersWidget.get_elm_saved_orders_s_description(s_description=s_description)),
                              s_description, 'Saved orders S.Description element.')

        self.browser.scroll_to_view(SavedOrdersWidget.get_elm_saved_orders_order_type(s_description=s_description))
        BuiltIn().run_keyword('should be equal',
                              self.browser.get_text(
                                  SavedOrdersWidget.get_elm_saved_orders_order_type(s_description=s_description)),
                              order_type, 'Saved orders Order Type element.')
        pass
