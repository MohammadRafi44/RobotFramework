from robot.libraries.BuiltIn import BuiltIn

from selenium.webdriver.common.by import By

from library import Browser


class OrderListWidget:
    # Objects
    # Elements
    _TAB_Order_list = (By.XPATH, '//div[@data-id="orderList-full"]//div[not(contains(@class,"active")) and '
                                 'contains(@class,"wdgttl-tab-item")]/a/span[text()="Order List"]', 'Order list Tab')
    _TAB_Order_list_Active = (By.XPATH, '//div[@data-id="orderList-full"]//div[contains(@class,"active") and '
                                        'contains(@class,"wdgttl-tab-item")]/a/span[text()="Order List"]',
                              'Order list Tab active')

    # Methods for Dynamic XPaths
    @staticmethod
    def get_elm_order_list_symbol(symbol: str):
        xpath = '//div[@data-id="orderList-full"]//div[@cell-id="symbolInfo.dSym"]/span[text()="{symbol}"]'.replace(
            '{symbol}', symbol)
        return By.XPATH, xpath, 'Order list Symbol element.'

    @staticmethod
    def get_elm_order_list_s_description(s_description: str):
        xpath = '//div[@data-id="orderList-full"]//div[@cell-id="symbolInfo.sDes"]' \
                '/span[text()="{s_description}"]'.replace('{s_description}', s_description)
        return By.XPATH, xpath, 'Order list S.Description element.'

    @staticmethod
    def get_elm_order_list_status(s_description: str):
        xpath = '//div[@data-id="orderList-full"]//div[@cell-id="symbolInfo.sDes"]' \
                '/span[text()="{s_description}"]/ancestor::div[contains(@class,"table-row")]' \
                '//div[@cell-id="ordSts"]/span'.replace('{s_description}', s_description)
        return By.XPATH, xpath, 'Order list Status element.'

    @staticmethod
    def get_elm_order_list_order_type(s_description: str):
        xpath = '//div[@data-id="orderList-full"]//div[@cell-id="symbolInfo.sDes"]' \
                '/span[text()="{s_description}"]/ancestor::div[contains(@class,"table-row")]' \
                '//div[@cell-id="ordTyp"]/span'.replace('{s_description}', s_description)
        return By.XPATH, xpath, 'Order list Order type element.'

    @staticmethod
    def get_elm_order_list_quantity(s_description: str):
        xpath = '//div[@data-id="orderList-full"]//div[@cell-id="symbolInfo.sDes"]' \
                '/span[text()="{s_description}"]/ancestor::div[contains(@class,"table-row")]' \
                '//div[@cell-id="ordQty"]/span'.replace('{s_description}', s_description)
        return By.XPATH, xpath, 'Order list Quantity element.'

    @staticmethod
    def get_elm_order_list_price(s_description: str):
        xpath = '//div[@data-id="orderList-full"]//div[@cell-id="symbolInfo.sDes"]' \
                '/span[text()="{s_description}"]/ancestor::div[contains(@class,"table-row")]' \
                '//div[@cell-id="price"]/span'.replace('{s_description}', s_description)
        return By.XPATH, xpath, 'Order list Price element.'

    def __init__(self, browser: Browser):
        self.browser = browser
        pass

    # Page functions
    def switch_to_order_list_tab(self):
        if not self.browser.is_element_present(locator=OrderListWidget._TAB_Order_list_Active):
            self.browser.click(locator=OrderListWidget._TAB_Order_list)
        self.browser.wait_for_element_present(locator=OrderListWidget._TAB_Order_list_Active)
        pass

    # Verify functions

    # Assert functions
    def assert_order_list_entry(self, order: dict):
        self.switch_to_order_list_tab()
        symbol = order['symbol']
        s_description = order['s_description']
        status = order['status']
        order_type = order['order_type']
        quantity = order['quantity']
        price = order['price']

        BuiltIn().run_keyword('should be equal',
                              self.browser.get_text(OrderListWidget.get_elm_order_list_symbol(symbol=symbol)),
                              symbol, 'Order list Symbol element.')

        BuiltIn().run_keyword('should be equal',
                              self.browser.get_text(
                                  OrderListWidget.get_elm_order_list_s_description(s_description=s_description)),
                              s_description, 'Order list S.Description element.')

        BuiltIn().run_keyword('should be equal',
                              self.browser.get_text(
                                  OrderListWidget.get_elm_order_list_status(s_description=s_description)),
                              status, 'Order list Status element.')

        BuiltIn().run_keyword('should be equal',
                              self.browser.get_text(
                                  OrderListWidget.get_elm_order_list_quantity(s_description=s_description)),
                              quantity, 'Order list Quantity element.')

        self.browser.scroll_to_view(OrderListWidget.get_elm_order_list_price(s_description=s_description))
        BuiltIn().run_keyword('should be equal',
                              float(self.browser.get_text(
                                  OrderListWidget.get_elm_order_list_price(s_description=s_description))),
                              float(price), 'Order list Price element.')

        self.browser.scroll_to_view(OrderListWidget.get_elm_order_list_order_type(s_description=s_description))
        BuiltIn().run_keyword('should be equal',
                              self.browser.get_text(
                                  OrderListWidget.get_elm_order_list_order_type(s_description=s_description)),
                              order_type, 'Order list Order Type element.')
        pass
