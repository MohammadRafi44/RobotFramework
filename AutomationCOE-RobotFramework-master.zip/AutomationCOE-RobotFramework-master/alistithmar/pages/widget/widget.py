from library import Browser

from alistithmar.pages.widget.saudi_stock_exchange_widget import SaudiStockExchangeWidget
from alistithmar.pages.widget.new_order_widget import NewOrderWidget
from alistithmar.pages.widget.order_list_widget import OrderListWidget
from alistithmar.pages.widget.saved_orders_widget import SavedOrdersWidget


class Widget:

    def __init__(self, browser: Browser):
        self.browser = browser
        self.saudi_stock_exchange = SaudiStockExchangeWidget(browser=self.browser)
        self.new_order = NewOrderWidget(browser=self.browser)
        self.order_list = OrderListWidget(browser=self.browser)
        self.saved_orders = SavedOrdersWidget(browser=self.browser)
        pass
