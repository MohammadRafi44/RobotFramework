import time

from selenium.webdriver.common.by import By

from library import Browser


class NewOrderWidget:
    # Objects
    # Button
    _BTN_Save_to_Basket = (
        By.XPATH, '//div[@id="order-ticket-landscape-id"]//button[text()="Save to Basket"]',
        'New order widget Save to Basket button')

    _BTN_Confirmation_Save_Order = \
        (By.XPATH, '//div[@container-id="orderConfirmation"]//button[text()="Save Order"]',
         'New order Save Order button.')

    # Text
    _TXT_Search = (
        By.XPATH, '//div[@id="order-ticket-landscape-id"]//input[contains(@id,"searchField")]',
        'New order widget Search input field.')
    _TXT_Quantity = (
        By.XPATH, '//div[@id="order-ticket-landscape-id"]//input[contains(@id,"qtyField")]',
        'New order widget Quantity input field.')
    _TXT_Price = (
        By.XPATH, '//div[@id="order-ticket-landscape-id"]//input[contains(@id,"orderPriceId")]',
        'New order widget Price input field.')

    # Drop Down
    _BTN_DRP_Order_Type = (
        By.XPATH, '//div[@id="order-ticket-landscape-id"]//div[text()="Order Type"]/following-sibling::div'
                  '//button[contains(@class,"btn-dropdown")]', 'New order widget Order Type button.')
    _ELM_DRP_Order_Type_Value = (
        By.XPATH, '//div[@id="order-ticket-landscape-id"]//div[text()="Order Type"]/following-sibling::div'
                  '//button[contains(@class,"btn-dropdown")]/div/div', 'New order widget Order Type value element.')

    _BTN_DRP_Good_Till = (
        By.XPATH, '//div[@id="order-ticket-landscape-id"]//div[text()="Good Till"]/following-sibling::div'
                  '//button[contains(@class,"btn-dropdown")]', 'New order widget Good Till button.')
    _ELM_DRP_Good_Till_Value = (
        By.XPATH, '//div[@id="order-ticket-landscape-id"]//div[text()="Good Till"]/following-sibling::div'
                  '//button[contains(@class,"btn-dropdown")]/div/div', 'New order widget Good Till value element.')

    # Methods for Dynamic XPaths
    @staticmethod
    def get_elm_drp_option(value: str):
        xpath = '//div[@container-id="popupId"]//a[text()="{value}"]'.replace('{value}', value)
        return By.XPATH, xpath, 'New order widget drop down option element.'

    def __init__(self, browser: Browser):
        self.browser = browser
        pass

    # Page functions
    def fill_buy_order(self):
        pass

    def save_to_basket(self, order: dict):
        order_type = order['order_type']
        quantity = order['quantity']
        good_till = order['good_till']

        self.browser.wait_for_element_visible(locator=NewOrderWidget._BTN_Save_to_Basket)

        self.browser.wait_for_element_clickable(locator=NewOrderWidget._BTN_DRP_Good_Till)
        self.browser.select_drop_down(button=NewOrderWidget._BTN_DRP_Good_Till,
                                      value_element=NewOrderWidget.get_elm_drp_option(
                                          value=good_till), value=good_till)

        self.browser.wait_for_element_clickable(locator=NewOrderWidget._BTN_DRP_Good_Till)
        self.browser.select_drop_down(button=NewOrderWidget._BTN_DRP_Order_Type,
                                      value_element=NewOrderWidget.get_elm_drp_option(
                                          value=order_type), value=order_type)

        self.browser.set_text(locator=NewOrderWidget._TXT_Quantity, value=quantity)

        time.sleep(2)
        self.browser.click(locator=NewOrderWidget._BTN_Save_to_Basket)

        self.browser.wait_for_element_visible(locator=NewOrderWidget._BTN_Confirmation_Save_Order)
        self.browser.click(locator=NewOrderWidget._BTN_Confirmation_Save_Order)
        pass

    # Verify functions

    # Assert functions
