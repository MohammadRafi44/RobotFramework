from library import Browser

from alistithmar.pages.login_page import LoginPage
from alistithmar.pages.home_page import HomePage


class AlistithmarPages:
    def __init__(self, browser):
        self.browser: Browser = browser
        self.login_page = LoginPage(browser=self.browser)
        self.home = HomePage(browser=self.browser)
        pass
