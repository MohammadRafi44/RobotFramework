import time
from robot.libraries.BuiltIn import BuiltIn

from selenium.webdriver.common.by import By

from library import Browser


class LoginPage:
    # Objects
    # Buttons
    _BTN_Login = (By.XPATH, '//button[text()="Login"]', 'Login button.')

    # Label element
    _LBL_Title_ICAP_Trade = (By.XPATH, '//title[text()="ICAP Trade"]', 'Title - ICAP Trade label.')

    # Message element
    _LBL_Msg_Initializing_Application = (
        By.XPATH, '//div[text()="Initializing Application..."]', 'Initializing Application... message.')

    # Error element
    _LBL_Error_Session_expired = (By.XPATH, '//div[text()="Session expired"]', 'Session expired error.')

    # Text
    _TXT_Username = (By.XPATH, '//input[@id="txtUsername" and @placeholder="Username"]', 'Username text.')
    _TXT_Password = (By.XPATH, '//input[@id="txtPassword" and @placeholder="Password"]', 'Password text.')

    def __init__(self, browser: Browser):
        self.browser = browser
        pass

    # Page functions
    def login(self, username: str, password: str):
        self.browser.wait_for_element_invisibility(locator=LoginPage._LBL_Msg_Initializing_Application)
        self.browser.wait_for_element_visible(locator=LoginPage._BTN_Login)
        self.browser.set_text(locator=LoginPage._TXT_Username, value=username)
        self.browser.set_text(locator=LoginPage._TXT_Password, value=password)
        self.browser.click(locator=LoginPage._BTN_Login)
        time.sleep(1)
        pass

    # Verify functions

    # Assert functions
    def assert_login_page_displayed(self):
        self.browser.wait_for_element_visible(locator=LoginPage._BTN_Login)
        BuiltIn().run_keyword('should be true', self.browser.is_element_displayed(LoginPage._BTN_Login),
                              'Login button displayed.')
        pass

    def assert_session_expired(self):
        self.browser.wait_for_element_visible(locator=LoginPage._LBL_Error_Session_expired)
        BuiltIn().run_keyword('should be true', self.browser.is_element_displayed(LoginPage._LBL_Error_Session_expired),
                              'Session expired error displayed.')
        pass
