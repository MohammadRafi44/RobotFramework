from alistithmar.pages.menu.menu import Menu
