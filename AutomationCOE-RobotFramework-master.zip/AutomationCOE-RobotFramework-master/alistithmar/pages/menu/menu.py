import time

from robot.libraries.BuiltIn import BuiltIn

from selenium.webdriver.common.by import By

from library import Browser


class Menu:
    # Objects
    # Button
    _BTN_Delete_Workspace = (
        By.XPATH, '//div[@container-id="popupId"]//a[text()="Delete Workspace"]', 'Delete Workspace button')
    _BTN_create_workspace = (
        By.XPATH, '//div[@id="horizontalPanel"]/div[contains(@class,"overflow")]//div[contains(@class,"app-menu")]',
        'Create Workspace button')

    _BTN_Delete_workspace_Confirmation_PopUp_Yes = (
        By.XPATH, '//div[@id="id="message-box""]', 'Delete workspace confirmation Yes button.')

    # Menu
    _Menu_Trade = (By.XPATH,
                   '//div[@id="horizontalPanel"]//div[contains(@id,"menuWrapper") and '
                   'not(contains(@class,"sidebar-active"))]//div[text()="Trade"]', 'Trade menu.')
    _Menu_Trade_Active = (By.XPATH,
                          '//div[@id="horizontalPanel"]//div[contains(@id,"menuWrapper") and '
                          'contains(@class,"sidebar-active")]//div[text()="Trade"]', 'Trade menu active.')

    # SubMenu
    _SubMenu_Trade_One_Stop_Trading = (
        By.XPATH,
        '//div[@id="horizontalPanel"]//div[@container-sub-menu-id="oneStop" and not(contains(@class,"active"))]'
        '/div[text()="One Stop Trading"]',
        'One Stop Trading sub menu.')
    _SubMenu_Trade_One_Stop_Trading_Active = (
        By.XPATH, '//div[@id="horizontalPanel"]//div[@container-sub-menu-id="oneStop" and contains(@class,"active")]'
                  '/div[text()="One Stop Trading"]',
        'One Stop Trading sub menu.')

    # Methods for Dynamic XPaths
    @staticmethod
    def get_elm_menu_workspace(workspace: str):
        xpath = '//div[contains(@id,"menuWrapper")]//div[contains(@class,"appmnu") and text()="{workspace}"]'.replace(
            '{workspace}', workspace)
        return By.XPATH, xpath, 'Workspace menu element.'

    @staticmethod
    def get_elm_workspace_burger_icon(workspace: str):
        xpath = '//div[contains(@id,"menuWrapper")]//div[contains(@class,"appmnu") and text()="{workspace}"]' \
                '/following::div/i[contains(@class,"hamburger")]'.replace('{workspace}', workspace)
        return By.XPATH, xpath, 'Workspace menu burger icon.'

    # Card
    @staticmethod
    def get_elm_card_widget_layout(layout):
        xpath = '//div[contains(@class ,"layout-container")]//table[{layout}]'.replace('{layout}', str(layout))
        return By.XPATH, xpath, 'Workspace widget layout card element.'

    def __init__(self, browser: Browser):
        self.browser = browser
        pass

    # Page functions
    def open_menu(self, menu: str, sub_menu: str):
        # TODO Implement menu navigation function.
        pass

    def is_workspace_exist(self, workspace_name: str):
        return self.browser.is_element_present(locator=Menu.get_elm_menu_workspace(workspace=workspace_name))

    def create_workspace(self, layout: str):
        self.browser.click(locator=Menu._BTN_create_workspace)
        self.browser.wait_for_element_visible(locator=Menu.get_elm_card_widget_layout(layout=layout))
        self.browser.click(locator=Menu.get_elm_card_widget_layout(layout=layout))
        pass

    def delete_workspace(self, workspace_name: str):
        self.browser.click(locator=Menu.get_elm_workspace_burger_icon(workspace=workspace_name))
        self.browser.wait_for_element_visible(locator=Menu._BTN_Delete_Workspace)
        self.browser.click(locator=Menu._BTN_Delete_Workspace)
        self.browser.wait_for_element_visible(locator=Menu._BTN_Delete_workspace_Confirmation_PopUp_Yes)
        self.browser.click(locator=Menu._BTN_Delete_workspace_Confirmation_PopUp_Yes)
        pass

    # Verify functions

    # Assert functions
    def assert_active_menu(self, menu: str, sub_menu: str = None):
        time.sleep(5)
        if menu in ['Trade']:
            BuiltIn().run_keyword('should be true', self.browser.is_element_displayed(
                locator=Menu._Menu_Trade_Active), 'Trade menu active.')
            if sub_menu in ['One Stop Trading']:
                BuiltIn().run_keyword('should be true', self.browser.is_element_displayed(
                    locator=Menu._SubMenu_Trade_One_Stop_Trading_Active), 'One Stop Trading sub menu active.')
        pass

    def assert_workspace_created(self, workspace_name: str):
        BuiltIn().run_keyword('should be true', self.browser.is_element_displayed(
            locator=Menu.get_elm_menu_workspace(workspace=workspace_name)), workspace_name + ' Workspace exist.')
        pass
