from library import Browser
from alistithmar.pages.title_bar import TitleBar
from alistithmar.pages.menu import Menu
from alistithmar.pages.widget import Widget


class HomePage:

    def __init__(self, browser: Browser):
        self.browser = browser
        self.title_bar = TitleBar(browser=self.browser)
        self.menu = Menu(browser=self.browser)
        self.widget = Widget(browser=self.browser)
        pass

    # Page functions

    # Verify functions

    # Assert functions
